/**
 * Created by KNB on 04.12.2017.
 *
 * Dieses Package beinhaltet die Klassen, die zur Steuerung des Programms und als Schnittstelle zur
 * grafischen Repräsentation nötig sind.
 *
 * Dieses Package ist Bestandteil des Frameworks und sollte nur mit ausreichendem Wissen geändert werden.
 */
package KAGO_framework.control;