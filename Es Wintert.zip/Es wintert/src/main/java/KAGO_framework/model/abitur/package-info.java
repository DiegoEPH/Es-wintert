/**
 * Created by KNB on 04.12.2017.
 * Dieses Package beinhaltet die für die gymnasiale Oberstufe (Q1/Q2) obligatorischen
 * Klassen gemäß der Vorgabe durch das Land.
 */
package KAGO_framework.model.abitur;